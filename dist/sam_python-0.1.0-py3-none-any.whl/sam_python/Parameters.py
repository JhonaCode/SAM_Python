########################################################
#File to define the direction of the SAM run´s.
########################################################

### My own files 

##Adress of the computer
from     files_direction  import *  

import   source.var_files.var_to_load_sam_core  as var_c

########################################################
#Files of SAM to load. 
########################################################

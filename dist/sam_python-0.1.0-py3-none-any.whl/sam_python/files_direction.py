# TO CONTROL THE COMPUTER DIRECTION 

##Silvio_pc =spc
#computer   ='/home/jhona'
computer    =''

#dataout document, overleaf project, clone
#file_fig    = "./figures_out/"%(computer)  

file_fig    = "./figures_out/"  

#dataout  temporal files ...document, overleaf project, clone
file_temp   = "./figures_out/"
